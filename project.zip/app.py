from flask import Flask, request, jsonify
import numpy as np
import joblib

app = Flask(__name__)
model = joblib.load("model.pkl")
class_names = ["class_0", "class_1", "class_2"]

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()
    features = np.array(data["features"]).reshape(1, -1)
    pred = int(model.predict(features)[0])
    return jsonify({"prediction": pred, "label": class_names[pred]})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
