from flask import Flask, request, jsonify
import pandas as pd
import joblib, json

app = Flask(__name__)
model = joblib.load("model.pkl")
with open("config.json") as f:
    config = json.load(f)
FEATURES = config["features"]

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"})

@app.route("/model-info", methods=["GET"])
def model_info():
    return jsonify(config)

@app.route("/predict", methods=["POST"])
def predict():
    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "Body harus berupa JSON"}), 400
    missing = [f for f in FEATURES if f not in data]
    if missing:
        return jsonify({"error": "Field kurang", "missing": missing}), 400
    try:
        df = pd.DataFrame([data])[FEATURES]
        pred = float(model.predict(df)[0])
    except Exception as e:
        return jsonify({"error": f"Input tidak valid: {e}"}), 400
    return jsonify({"predicted_charges": round(pred, 2)})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
